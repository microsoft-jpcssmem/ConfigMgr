﻿#####################################################################################
#　共有フォルダのアクセス権設定
#　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　ver 1.0.0
#　2020/05/20　　　新規作成
#####################################################################################
#　共有フォルダの確認
#####################################################################################
#
$SF = "C:\ABC\csv\"
Write-Output 1 | Out-File -FilePath c:\debug-set.txt -Append -Encoding 'utf8'
$UN = Get-ItemPropertyValue -Path "HKCU:Environment" -Name "WIN10LUSER"
Write-Output 2 | Out-File -FilePath c:\debug-set.txt -Append -Encoding 'utf8'

#####################################################################################
#　フォルダの作成
#####################################################################################
#
$CKCF = Get-ChildItem $SF -ErrorAction 'silentlycontinue'   
Write-Output 3 | Out-File -FilePath c:\debug-set.txt -Append -Encoding 'utf8'
If (!($CKCF)){
    Write-Output 4 | Out-File -FilePath c:\debug-set.txt -Append -Encoding 'utf8'
    New-item $SF -itemtype Directory -ErrorAction 'silentlycontinue'
    Write-Output 5 | Out-File -FilePath c:\debug-set.txt -Append -Encoding 'utf8'
}

#####################################################################################
#　共有設定／アクセス権の設定
#####################################################################################
#
Write-Output 6 | Out-File -FilePath c:\debug-set.txt -Append -Encoding 'utf8'
$CKSF = Get-SmbShare | Where-Object {$_.Name -eq $UN } -ErrorAction 'silentlycontinue'
Write-Output 7 | Out-File -FilePath c:\debug-set.txt -Append -Encoding 'utf8'
If (!($CKSF)){
    Write-Output 8 | Out-File -FilePath c:\debug-set.txt -Append -Encoding 'utf8'
    New-SmbShare -Name csv -Path $SF -ReadAccess $UN -ErrorAction 'silentlycontinue'
    Write-Output 9 | Out-File -FilePath c:\debug-set.txt -Append -Encoding 'utf8'
}
Write-Output 10 | Out-File -FilePath c:\debug-set.txt -Append -Encoding 'utf8'

#####################################################################################
#　環境変数設定の削除
#####################################################################################
#
Remove-ItemProperty -Path "HKCU:Environment" -Name "WIN10LUSER"
Write-Output 11 | Out-File -FilePath c:\debug-set.txt -Append -Encoding 'utf8'