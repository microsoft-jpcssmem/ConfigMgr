﻿# InitialSetting

$site_code = "LH1"
$result_path = "c:\work\"
$result_csv_path = $result_path + "result.csv"

$sql_host = "localhost"

$base_csv_file   = $result_path + "Device.csv"
$nic_csv_file    = $result_path + "Nic.csv"
$office_csv_file = $result_path + "office.csv"

# Pre-Process

$base_query   = "`"select sys.ResourceID, sys.Name0, sys.User_Name0, sys.User_Domain0, sys.Last_Logon_Timestamp0, os.Version0 from CM_{0}..v_R_System as sys join CM_{0}..v_GS_OPERATING_SYSTEM as os on os.ResourceID = sys.ResourceID`"" -f $site_code
$nic_query    = "`"select nic.ResourceID, nic.IPAddress0, nic.ServiceName0 from CM_{0}..v_GS_NETWORK_ADAPTER_CONFIGURATION as nic where nic.IPEnabled0 = 1`"" -f $site_code
$office_query = "`"select office.ResourceID, office.VersionToReport0 from CM_{0}..v_GS_OFFICE365PROPLUSCONFIGURATIONS as office`"" -f $site_code

# Main Process
$base_args   = @($base_query,   "queryout", $base_csv_file,   "-c", "-S", $sql_host, "-T")
$nic_args    = @($nic_query,    "queryout", $nic_csv_file,    "-c", "-S", $sql_host, "-T")
$office_args = @($office_query, "queryout", $office_csv_file, "-c", "-S", $sql_host, "-T")

## Get-CSV
Start-Process -FilePath bcp -ArgumentList $base_args -Wait
Start-Process -FilePath bcp -ArgumentList $nic_args -Wait
Start-Process -FilePath bcp -ArgumentList $office_args -Wait

$base_objs   = Import-Csv -Path $base_csv_file   -Delimiter `t -Header @("ResourceID", "Name", "UserName", "UserDomain", "LastLogon", "osVersion") | Sort-Object -Property ResrouceID
$nic_objs    = Import-Csv -Path $nic_csv_file    -Delimiter `t -Header @("ResourceID", "IPAddress", "ServiceName") | Sort-Object -Property ResrouceID
$office_objs = Import-Csv -Path $office_csv_file -Delimiter `t -Header @("ResourceID", "officeVersion") | Sort-Object -Property ResrouceID

## Transform NIC data

### Remove v6 address

$v6_regex = "((([0-9a-f]{1,4}:){7}([0-9a-f]{1,4}|:))|(([0-9a-f]{1,4}:){6}(:[0-9a-f]{1,4}|((25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)(\.(25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)){3})|:))|(([0-9a-f]{1,4}:){5}(((:[0-9a-f]{1,4}){1,2})|:((25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)(\.(25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)){3})|:))|(([0-9a-f]{1,4}:){4}(((:[0-9a-f]{1,4}){1,3})|((:[0-9a-f]{1,4})?:((25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)(\.(25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)){3}))|:))|(([0-9a-f]{1,4}:){3}(((:[0-9a-f]{1,4}){1,4})|((:[0-9a-f]{1,4}){0,2}:((25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)(\.(25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)){3}))|:))|(([0-9a-f]{1,4}:){2}(((:[0-9a-f]{1,4}){1,5})|((:[0-9a-f]{1,4}){0,3}:((25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)(\.(25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)){3}))|:))|(([0-9a-f]{1,4}:){1}(((:[0-9a-f]{1,4}){1,6})|((:[0-9a-f]{1,4}){0,4}:((25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)(\.(25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)){3}))|:))|(:(((:[0-9a-f]{1,4}){1,7})|((:[0-9a-f]{1,4}){0,5}:((25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)(\.(25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)){3}))|:)))(%.+)?\s*"

foreach($nic in $nic_objs){    
    $nic.IPAddress = $nic.IPAddress -replace $v6_regex, ""    
    $nic.IPAddress = $nic.IPAddress -replace ",", ""
}

### Aggregation IPAddress

$machine_ips = @()

for ($i = 0; $i -lt $nic_objs.Count; $i++){    
    $id = $nic_objs[$i].ResourceID    
    $ip = $nic_objs[$i].IPAddress

    $j = $i + 1    
    while ($j -lt $nic_objs.Count){
        if($id -ne $nic_objs[$j].ResourceID){
            break
        }
        $ip += "/" + $nic_objs[$j].IPAddress
        $j++
    }

    $machine_ips += New-Object PSObject -Property @{ResourceID=$id; IPAddress=$ip}
    $i = $j - 1

}

### Build Results

$results = @()

foreach($base in $base_objs){
   $id = $base.ResourceID

   $target_ip = $machine_ips | where ResourceID -eq $id 
   
   $result_ip = ""
   if($target_ip -ne $null){
     $result_ip = $target_ip.IPAddress
   }

   $target_office = $office_objs | where ResourceID -eq $id

   $result_office_ver = ""
   if($target_office -ne $null){
     $result_office_ver = $target_office.officeVersion
   }

   $results += New-Object PSObject -Property @{Name=$base.Name; UserName=$base.UserName; UserDomain=$base.UserDomain; LastLogon = $base.LastLogon; osVersion = $base.osVersion; IPAddress = $result_ip; officeVersion = $result_office_ver}
}

# Export-CSV
$results |select Name, UserName, UserDomain, LastLogon, osVersion, IPAddress, officeVersion | Export-CSV -Path $result_csv_path 